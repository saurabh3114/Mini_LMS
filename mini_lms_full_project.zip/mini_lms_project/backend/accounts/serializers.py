"""
accounts/serializers.py
Serializers for user registration, login, and profile.
"""
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from .models import User


class RegisterSerializer(serializers.ModelSerializer):
    """Handles new user registration with password validation."""

    password  = serializers.CharField(write_only=True, min_length=6)
    password2 = serializers.CharField(write_only=True, label='Confirm password')

    class Meta:
        model  = User
        fields = ['username', 'email', 'password', 'password2', 'role']
        extra_kwargs = {
            'role': {'required': False},
        }

    def validate(self, attrs):
        if attrs['password'] != attrs.pop('password2'):
            raise serializers.ValidationError({'password': 'Passwords do not match.'})
        try:
            validate_password(attrs['password'])
        except ValidationError as e:
            raise serializers.ValidationError({'password': list(e.messages)})
        # Only allow student/instructor self-registration (not admin)
        role = attrs.get('role', 'student')
        if role == 'admin':
            raise serializers.ValidationError({'role': 'Cannot self-register as admin.'})
        return attrs

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password'],
            role=validated_data.get('role', 'student'),
        )
        return user


class UserSerializer(serializers.ModelSerializer):
    """Read-only user profile serializer."""

    class Meta:
        model  = User
        fields = ['id', 'username', 'email', 'role', 'bio', 'is_active', 'date_joined']
        read_only_fields = ['id', 'date_joined']


class UserListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for admin user listing."""

    class Meta:
        model  = User
        fields = ['id', 'username', 'email', 'role', 'is_active', 'date_joined']


class TokenResponseSerializer(serializers.Serializer):
    """Returns JWT token pair + user info on login/register."""

    access  = serializers.CharField()
    refresh = serializers.CharField()
    user    = UserSerializer()

    @staticmethod
    def get_tokens_for_user(user):
        refresh = RefreshToken.for_user(user)
        return {
            'access':  str(refresh.access_token),
            'refresh': str(refresh),
            'user':    UserSerializer(user).data,
        }
