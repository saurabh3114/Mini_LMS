"""
accounts/views.py
Authentication & user management views.
"""
from django.contrib.auth import authenticate
from rest_framework import status, generics
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from .models import User
from .serializers import (
    RegisterSerializer,
    UserSerializer,
    UserListSerializer,
    TokenResponseSerializer,
)


class LoginRateThrottle(AnonRateThrottle):
    """Stricter throttle for login endpoint — 5 attempts/min."""
    rate = '5/min'


# ─── Register ─────────────────────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
def register_view(request):
    """
    POST /api/accounts/register/
    Register a new student or instructor account.
    """
    serializer = RegisterSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    user = serializer.save()
    return Response(
        TokenResponseSerializer.get_tokens_for_user(user),
        status=status.HTTP_201_CREATED,
    )


# ─── Login ────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
@throttle_classes([LoginRateThrottle])
def login_view(request):
    """
    POST /api/accounts/login/
    Authenticate and return JWT access + refresh tokens.
    """
    username = request.data.get('username', '').strip()
    password = request.data.get('password', '')

    if not username or not password:
        return Response(
            {'error': 'Username and password are required.'},
            status=status.HTTP_400_BAD_REQUEST,
        )

    user = authenticate(request, username=username, password=password)

    if user is None:
        return Response(
            {'error': 'Invalid credentials. Please check your username and password.'},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    if not user.is_active:
        return Response(
            {'error': 'Your account has been disabled. Contact an administrator.'},
            status=status.HTTP_403_FORBIDDEN,
        )

    return Response(TokenResponseSerializer.get_tokens_for_user(user))


# ─── Current User ─────────────────────────────────────────────────────────────
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def me_view(request):
    """
    GET /api/accounts/me/
    Returns the currently authenticated user's profile.
    """
    return Response(UserSerializer(request.user).data)


# ─── Update Profile ───────────────────────────────────────────────────────────
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_profile_view(request):
    """
    PATCH /api/accounts/me/
    Update email or bio for the current user.
    """
    allowed_fields = {'email', 'bio'}
    data = {k: v for k, v in request.data.items() if k in allowed_fields}
    serializer = UserSerializer(request.user, data=data, partial=True)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    serializer.save()
    return Response(serializer.data)


# ─── Admin: List All Users ────────────────────────────────────────────────────
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_users_view(request):
    """
    GET /api/accounts/users/
    Admin-only: returns all registered users.
    """
    if not request.user.is_admin:
        return Response({'error': 'Admin access required.'}, status=status.HTTP_403_FORBIDDEN)

    users = User.objects.all().order_by('role', 'username')
    return Response(UserListSerializer(users, many=True).data)


# ─── Admin: Toggle User Active ────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def toggle_user_view(request, user_id):
    """
    POST /api/accounts/users/<user_id>/toggle/
    Admin-only: enable or disable a user account.
    """
    if not request.user.is_admin:
        return Response({'error': 'Admin access required.'}, status=status.HTTP_403_FORBIDDEN)

    try:
        target = User.objects.get(pk=user_id)
    except User.DoesNotExist:
        return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)

    if target == request.user:
        return Response({'error': 'Cannot disable your own account.'}, status=status.HTTP_400_BAD_REQUEST)

    target.is_active = not target.is_active
    target.save()
    return Response({
        'success': True,
        'user_id': target.id,
        'is_active': target.is_active,
    })


# ─── Token Refresh ────────────────────────────────────────────────────────────
token_refresh_view = TokenRefreshView.as_view()
