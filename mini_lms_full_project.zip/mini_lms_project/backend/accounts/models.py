"""
accounts/models.py
Custom User model with role-based access (Admin, Instructor, Student).
"""
from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Extended user with LMS role."""

    class Role(models.TextChoices):
        ADMIN      = 'admin',      'Admin'
        INSTRUCTOR = 'instructor', 'Instructor'
        STUDENT    = 'student',    'Student'

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.STUDENT,
    )
    email = models.EmailField(unique=True, blank=True, null=True)
    bio   = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    # Properties for cleaner permission checks
    @property
    def is_admin(self):
        return self.role == self.Role.ADMIN

    @property
    def is_instructor(self):
        return self.role in (self.Role.INSTRUCTOR, self.Role.ADMIN)

    @property
    def is_student(self):
        return self.role == self.Role.STUDENT

    def __str__(self):
        return f'{self.username} ({self.role})'

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['username']
