"""
accounts/urls.py
URL routing for authentication & user management.
"""
from django.urls import path
from . import views

urlpatterns = [
    path('register/',               views.register_view,     name='register'),
    path('login/',                  views.login_view,        name='login'),
    path('me/',                     views.me_view,           name='me'),
    path('me/update/',              views.update_profile_view, name='update-profile'),
    path('token/refresh/',          views.token_refresh_view, name='token-refresh'),
    path('users/',                  views.list_users_view,   name='list-users'),
    path('users/<int:user_id>/toggle/', views.toggle_user_view, name='toggle-user'),
]
