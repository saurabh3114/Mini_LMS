/**
 * assignments.js — Assignment listing, submission, and grading.
 * Depends on auth.js being loaded first.
 */

const ME = getUser();
let allAssignments = [];
let assignFilter   = 'all';
let currentAssignId  = null;
let currentStudentId = null;

// ─── Init ─────────────────────────────────────────────────────────────────────
(async function init() {
  if (!ME) return;

  // Hide student-only filters for instructors
  if (ME.role !== 'student') {
    const pf = document.getElementById('pending-filt');
    if (pf) pf.style.display = 'none';
  }

  // Show instructor nav
  if (ME.role === 'instructor' || ME.role === 'admin') {
    const instNav = document.getElementById('inst-nav');
    if (instNav) instNav.style.display = 'block';
    await updatePendingBadge();
    await populateCourseDropdown();
  }

  await loadAssignments();
})();

// ─── Assignments ──────────────────────────────────────────────────────────────
async function loadAssignments() {
  const data = await apiFetch('GET', '/courses/assignments/');
  if (!data) return;
  allAssignments = data;
  renderAssignments();
}

function renderAssignments() {
  const list = document.getElementById('assign-list');
  if (!list) return;

  let filtered = [...allAssignments];
  if (assignFilter === 'pending')   filtered = filtered.filter(a => !a.my_submission);
  if (assignFilter === 'submitted') filtered = filtered.filter(a => a.my_submission && a.my_grade == null);
  if (assignFilter === 'graded')    filtered = filtered.filter(a => a.my_grade != null);

  if (!filtered.length) {
    list.innerHTML = `<div class="empty"><span class="e-icon">📝</span><p>No assignments found</p></div>`;
    return;
  }

  list.innerHTML = filtered.map(a => {
    const cls    = a.my_grade != null ? 'done' : a.my_submission ? 'sub' : 'new';
    const subCnt = a.submission_count;
    const escapedTitle   = sanitize(a.title).replace(/'/g,"&#39;");
    const escapedCourse  = sanitize(a.course_title).replace(/'/g,"&#39;");
    const escapedContent = sanitize(a.my_submission || '').replace(/'/g,"&#39;");

    return `<div class="assign-item">
      <div class="a-dot ${cls}"></div>
      <div class="a-info">
        <div class="a-title">${sanitize(a.title)}</div>
        <div class="a-meta">
          <span>📚 ${sanitize(a.course_title)}</span>
          <span>📅 ${a.due_date || 'No deadline'}</span>
          <span>🏆 ${a.max_marks} marks</span>
          ${ME.role !== 'student' ? `<span>📤 ${subCnt} submissions</span>` : ''}
          ${a.my_submission && a.my_grade == null
            ? '<span style="color:var(--warning)">⏳ Awaiting grade</span>' : ''}
          ${a.my_grade != null
            ? '<span style="color:var(--success)">✅ Graded</span>' : ''}
        </div>
      </div>
      ${a.my_grade != null
        ? `<span class="grade-pill">${a.my_grade}/${a.max_marks}</span>` : ''}
      ${ME.role === 'student'
        ? `<button class="btn btn-primary btn-sm"
             onclick="openSubmitModal(${a.id},'${escapedTitle}','${escapedCourse}',${a.max_marks},'${escapedContent}')">
             ${a.my_submission ? '✏️ Edit' : '📤 Submit'}
           </button>`
        : ''}
    </div>`;
  }).join('');
}

function afilt(f, btn) {
  assignFilter = f;
  document.querySelectorAll('#assignments-view .filter-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  renderAssignments();
}

// ─── Submit Modal ─────────────────────────────────────────────────────────────
function openSubmitModal(id, title, course, maxMarks, existing) {
  currentAssignId = id;
  document.getElementById('submit-info').innerHTML =
    `<strong>${title}</strong><br>
     <span style="color:var(--text2);">Course: ${course} · Max: ${maxMarks} marks</span>`;
  document.getElementById('sub-content').value = existing || '';
  openModal('modal-submit');
}

async function submitWork() {
  const content = document.getElementById('sub-content').value.trim();
  if (!content) { toast('Please write something!', 'err'); return; }

  const data = await apiFetch('POST', '/courses/submit/', {
    assignment: currentAssignId,
    content,
  });
  if (data?.error || data?.content) {
    toast(data?.content?.[0] || data?.error || 'Submission failed', 'err');
    return;
  }
  toast('Submitted successfully! 🎉', 'ok');
  closeModal('modal-submit');
  await loadAssignments();
}

// ─── Grade Panel ──────────────────────────────────────────────────────────────
function showAssignView() {
  document.getElementById('assignments-view').style.display = 'block';
  document.getElementById('grade-view').style.display       = 'none';
}

async function showGradePanel() {
  document.getElementById('assignments-view').style.display = 'none';
  document.getElementById('grade-view').style.display       = 'block';

  const gc = document.getElementById('grade-content');
  if (gc) gc.innerHTML = '<div class="loading">Loading submissions...</div>';

  const assignments = await apiFetch('GET', '/courses/assignments/');
  if (!assignments) return;

  // Load submissions for each assignment in parallel
  const withSubs = await Promise.all(
    assignments.map(async a => {
      const subs = await apiFetch('GET', `/courses/assignments/${a.id}/submissions/`);
      return { assignment: a, submissions: subs || [] };
    })
  );

  const hasSubs = withSubs.filter(x => x.submissions.length > 0);

  if (!gc) return;

  if (!hasSubs.length) {
    gc.innerHTML = `<div class="empty"><span class="e-icon">📤</span><p>No submissions yet</p></div>`;
    return;
  }

  gc.innerHTML = hasSubs.map(({ assignment: a, submissions: subs }) => `
    <div class="card" style="margin-bottom:14px;">
      <div class="card-head">
        <div>
          <div style="font-weight:700;">${sanitize(a.title)}</div>
          <div style="font-size:12px; color:var(--text2);">${sanitize(a.course_title)} · Max: ${a.max_marks}</div>
        </div>
        <span class="chip chip-blue">${subs.length} submissions</span>
      </div>
      <table class="tbl">
        <thead>
          <tr><th>Student</th><th>Answer</th><th>Grade</th><th>Action</th></tr>
        </thead>
        <tbody>
          ${subs.map(s => {
            const content  = sanitize(s.content || '');
            const username = sanitize(s.student_name || '?');
            const feedback = sanitize(s.feedback || '');
            return `<tr>
              <td><strong>${username}</strong><br>
                <span style="font-size:11px; color:var(--text2);">${sanitize(s.student_email||'')}</span>
              </td>
              <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:12px; color:var(--text2);"
                  title="${content}">${content || '—'}</td>
              <td>${s.grade != null
                ? `<span class="grade-pill">${s.grade}</span>`
                : '<span style="color:var(--text3)">—</span>'}</td>
              <td>
                <button class="btn btn-primary btn-xs"
                  onclick="openGradeModal(${a.id},${s.student},
                    '${username}','${content.replace(/'/g,"&#39;")}',
                    ${a.max_marks},${s.grade ?? 'null'},'${feedback.replace(/'/g,"&#39;")}')">
                  ⭐ Grade
                </button>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`).join('');
}

function openGradeModal(assignId, studentId, username, content, maxMarks, grade, feedback) {
  currentAssignId  = assignId;
  currentStudentId = studentId;
  document.getElementById('g-max').textContent = maxMarks;
  document.getElementById('grade-info').innerHTML =
    `<strong>${username}'s submission:</strong>
     <div style="margin-top:8px; padding:10px; background:var(--bg); border-radius:7px;
       font-family:monospace; font-size:12px; white-space:pre-wrap;
       max-height:120px; overflow-y:auto; color:var(--text2);">${content || '(empty)'}</div>`;
  document.getElementById('g-val').value      = grade !== 'null' && grade != null ? grade : '';
  document.getElementById('g-val').max        = maxMarks;
  document.getElementById('g-feedback').value = feedback || '';
  openModal('modal-grade');
}

async function saveGrade() {
  const grade    = parseInt(document.getElementById('g-val').value);
  const feedback = document.getElementById('g-feedback').value.trim();
  if (isNaN(grade) || grade < 0) { toast('Enter a valid grade', 'err'); return; }

  const data = await apiFetch(
    'POST',
    `/courses/assignments/${currentAssignId}/grade/${currentStudentId}/`,
    { grade, feedback }
  );
  if (data?.error || data?.grade) {
    toast(data?.grade?.[0] || data?.error || 'Grading failed', 'err');
    return;
  }
  toast('Grade saved! ⭐', 'ok');
  closeModal('modal-grade');
  showGradePanel();
  updatePendingBadge();
}

// ─── Create Assignment Modal ──────────────────────────────────────────────────
async function populateCourseDropdown() {
  const data = await apiFetch('GET', '/courses/');
  if (!data) return;
  const sel = document.getElementById('ca-course');
  if (!sel) return;
  sel.innerHTML = data.map(c => `<option value="${c.id}">${sanitize(c.title)}</option>`).join('');
}

function showCreateAssignModal() {
  document.getElementById('ca-title').value = '';
  document.getElementById('ca-desc').value  = '';
  document.getElementById('ca-due').value   = '';
  document.getElementById('ca-marks').value = '100';
  openModal('modal-create-assign');
}

async function createAssign() {
  const course_id = parseInt(document.getElementById('ca-course').value);
  const title     = document.getElementById('ca-title').value.trim();
  const description = document.getElementById('ca-desc').value.trim();
  const due_date  = document.getElementById('ca-due').value;
  const max_marks = parseInt(document.getElementById('ca-marks').value) || 100;

  if (!title) { toast('Assignment title required', 'err'); return; }

  const data = await apiFetch('POST', '/courses/assignments/', {
    course: course_id, title, description, due_date, max_marks,
  });
  if (data?.error || data?.title) {
    toast(data?.title?.[0] || data?.error || 'Failed to create assignment', 'err');
    return;
  }
  toast('Assignment created! 📝', 'ok');
  closeModal('modal-create-assign');
  await loadAssignments();
}

// ─── Pending Badge ────────────────────────────────────────────────────────────
async function updatePendingBadge() {
  const data = await apiFetch('GET', '/courses/stats/');
  if (!data) return;
  const badge = document.getElementById('pending-badge');
  if (!badge) return;
  if (data.pending_grade > 0) {
    badge.textContent   = data.pending_grade;
    badge.style.display = 'inline-flex';
  } else {
    badge.style.display = 'none';
  }
}
