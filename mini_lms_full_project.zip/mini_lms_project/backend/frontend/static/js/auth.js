/**
 * auth.js — Shared authentication utilities for Mini LMS.
 * Included on every page. Handles JWT storage, session guard,
 * sidebar setup, login/register, logout, and toast notifications.
 */

const API = '/api';

// ─── Token Management ─────────────────────────────────────────────────────────
function getToken()        { return sessionStorage.getItem('lms_token'); }
function getUser()         { const u = sessionStorage.getItem('lms_user'); return u ? JSON.parse(u) : null; }
function saveSession(t, u) { sessionStorage.setItem('lms_token', t); sessionStorage.setItem('lms_user', JSON.stringify(u)); }
function clearSession()    { sessionStorage.removeItem('lms_token'); sessionStorage.removeItem('lms_user'); }

// ─── Auth Guard ───────────────────────────────────────────────────────────────
// Any page other than index.html must have a valid session or redirect to login.
(function authGuard() {
  const isLoginPage = window.location.pathname === '/' || window.location.pathname === '';
  const token = getToken();
  const user  = getUser();

  if (!isLoginPage && (!token || !user)) {
    window.location.href = '/';
    return;
  }

  if (!isLoginPage && user) {
    setupSidebar(user);
  }
})();

// ─── Sidebar Setup ────────────────────────────────────────────────────────────
function setupSidebar(user) {
  const av = document.getElementById('s-av');
  if (av) {
    av.textContent  = user.username[0].toUpperCase();
    av.className    = `s-avatar av-${user.role}`;
  }
  const nameEl = document.getElementById('s-name');
  const roleEl = document.getElementById('s-role');
  if (nameEl) nameEl.textContent = user.username;
  if (roleEl) roleEl.textContent = user.role;

  if (user.role === 'instructor' || user.role === 'admin') {
    const instNav = document.getElementById('inst-nav');
    if (instNav) instNav.style.display = 'block';
  }
  if (user.role === 'admin') {
    const adminNav = document.getElementById('admin-nav');
    if (adminNav) adminNav.style.display = 'block';
  }
}

// ─── API Helper ───────────────────────────────────────────────────────────────
async function apiFetch(method, path, body) {
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };
  const token = getToken();
  if (token) opts.headers['Authorization'] = `Bearer ${token}`;
  if (body)  opts.body = JSON.stringify(body);

  const res = await fetch(API + path, opts);

  // Token expired — redirect to login
  if (res.status === 401 && !path.includes('/login')) {
    clearSession();
    toast('Session expired. Please log in again.', 'err');
    setTimeout(() => window.location.href = '/', 1500);
    return null;
  }

  return res.json();
}

// ─── Login Page Logic ─────────────────────────────────────────────────────────
// Only runs on the login page
if (window.location.pathname === '/' || window.location.pathname === '') {
  // If already logged in, redirect to courses
  if (getToken() && getUser()) {
    window.location.href = '/courses/';
  }
}

// Demo password reference (shown in the hint card — never sent automatically)
const DEMO_PASSWORDS = {
  'admin':      'Admin@2025!',
  'prof_smith': 'Teach#Smith99',
  'prof_jones': 'Jones@Prof2025',
  'alice':      'Alice#Pass1',
  'bob':        'Bob#Pass1',
  'charlie':    'Charlie#Pass1',
  'diana':      'Diana#Pass1',
  'eve':        'Eve#Pass1',
  'frank':      'Frank#Pass1',
  'grace':      'Grace#Pass1',
  'henry':      'Henry#Pass1',
};

function swTab(t) {
  ['login','reg'].forEach(id => {
    document.getElementById(`f-${id}`).style.display = id === t ? 'block' : 'none';
    document.getElementById(`t-${id}`).classList.toggle('on', id === t);
  });
}

// Quick select — fills ONLY username, clears password, shows hint card
function ql(username) {
  swTab('login');
  document.getElementById('l-user').value = username;
  document.getElementById('l-pass').value = '';           // Never auto-fill password

  // Show password hint reference card
  const hint    = document.getElementById('pw-hint');
  const hintU   = document.getElementById('pw-hint-user');
  const hintVal = document.getElementById('pw-hint-val');
  if (hint && DEMO_PASSWORDS[username]) {
    hintU.textContent   = username;
    hintVal.textContent = DEMO_PASSWORDS[username];
    hint.style.display  = 'block';
  }

  // Focus password field — user must type it manually
  setTimeout(() => document.getElementById('l-pass')?.focus(), 50);
}

// Hide hint card once user starts typing
function onPwType() {
  const hint = document.getElementById('pw-hint');
  const val  = document.getElementById('l-pass')?.value;
  if (hint && val && val.length > 0) hint.style.display = 'none';
}

// Login submit
async function doLogin() {
  const username = document.getElementById('l-user')?.value.trim();
  const password = document.getElementById('l-pass')?.value;
  const errEl    = document.getElementById('login-error');

  if (errEl) errEl.style.display = 'none';
  if (!username || !password) {
    showFormError('login-error', 'Please enter username and password.');
    return;
  }

  const btn = document.getElementById('login-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Signing in...'; }

  const data = await apiFetch('POST', '/accounts/login/', { username, password });

  if (btn) { btn.disabled = false; btn.textContent = 'Sign In →'; }

  if (!data || data.error) {
    showFormError('login-error', data?.error || 'Login failed. Please try again.');
    // Shake the box
    const box = document.querySelector('.auth-box');
    if (box) { box.style.animation = 'shake .35s ease'; setTimeout(() => box.style.animation = '', 400); }
    return;
  }

  saveSession(data.access, data.user);
  toast(`Welcome, ${data.user.username}! 🎉`, 'ok');
  setTimeout(() => window.location.href = '/courses/', 500);
}

// Register submit
async function doRegister() {
  const username  = document.getElementById('r-user')?.value.trim();
  const email     = document.getElementById('r-email')?.value.trim();
  const password  = document.getElementById('r-pass')?.value;
  const password2 = document.getElementById('r-pass2')?.value;
  const role      = document.getElementById('r-role')?.value;

  if (!username || !password) { showFormError('reg-error', 'Username and password required.'); return; }
  if (username.length < 3)    { showFormError('reg-error', 'Username must be at least 3 characters.'); return; }
  if (!/^[a-zA-Z0-9_]+$/.test(username)) { showFormError('reg-error', 'Username: letters, numbers, underscore only.'); return; }
  if (password.length < 6)    { showFormError('reg-error', 'Password must be at least 6 characters.'); return; }
  if (password !== password2) { showFormError('reg-error', 'Passwords do not match.'); return; }

  const data = await apiFetch('POST', '/accounts/register/', { username, email, password, password2, role });

  if (!data || data.username || data.password || data.error) {
    const msg = data?.username?.[0] || data?.password?.[0] || data?.error || 'Registration failed.';
    showFormError('reg-error', msg);
    return;
  }

  saveSession(data.access, data.user);
  toast(`Account created! Welcome, ${data.user.username} 🎉`, 'ok');
  setTimeout(() => window.location.href = '/courses/', 500);
}

// Password strength indicator
function showPwStrength(pw) {
  const bar = document.getElementById('pw-bar');
  const lbl = document.getElementById('pw-label');
  if (!bar || !lbl) return;

  let s = 0;
  if (pw.length >= 8)          s++;
  if (/[A-Z]/.test(pw))        s++;
  if (/[0-9]/.test(pw))        s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;

  const colors = ['#F87171','#FB923C','#FBBF24','#34D399'];
  const labels = ['Very Weak 🔴','Weak 🟠','Moderate 🟡','Strong 🟢'];
  if (!pw) { bar.style.background = 'var(--border)'; lbl.textContent = ''; return; }
  bar.style.background = `linear-gradient(90deg, ${colors[s-1]||'#3D4F7A'} ${s*25}%, var(--border) ${s*25}%)`;
  lbl.textContent = labels[s-1] || '';
  lbl.style.color = colors[s-1] || 'var(--text3)';
}

// ─── Logout ───────────────────────────────────────────────────────────────────
function logout() {
  clearSession();
  toast('Logged out successfully.', 'info');
  setTimeout(() => window.location.href = '/', 400);
}

// ─── Shared Helpers ───────────────────────────────────────────────────────────
function showFormError(elId, msg) {
  const el = document.getElementById(elId);
  if (!el) { toast(msg, 'err'); return; }
  el.textContent    = msg;
  el.style.display  = 'block';
}

function toast(msg, type = 'info') {
  const icons = { ok:'✅', err:'❌', info:'ℹ️' };
  const el    = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type]||'💬'}</span><span>${msg}</span>`;
  const container = document.getElementById('toasts');
  if (container) container.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

function openModal(id)  { const el = document.getElementById(id); if (el) el.classList.add('on'); }
function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.remove('on'); }

// Close modal on backdrop click
document.addEventListener('click', e => {
  if (e.target.classList.contains('overlay')) e.target.classList.remove('on');
});

// Enter key on login form
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && document.getElementById('f-login')?.style.display !== 'none') {
    const active = document.activeElement;
    if (active && (active.id === 'l-user' || active.id === 'l-pass')) doLogin();
  }
});

function sanitize(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
