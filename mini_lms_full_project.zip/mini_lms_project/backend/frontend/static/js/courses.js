/**
 * courses.js — Course listing, enrollment, and lesson management.
 * Depends on auth.js being loaded first.
 */

const ME = getUser();
let allCourses = [];
let courseFilter = 'all';
let courseSearch = '';

const BANNERS = ['ban1','ban2','ban3','ban4','ban5','ban6'];
const EMOJIS  = ['📘','📗','📙','📕','📓','📔'];

// ─── Init ─────────────────────────────────────────────────────────────────────
(async function init() {
  if (!ME) return;

  // Show create-course button for instructors/admins
  if (ME.role === 'instructor' || ME.role === 'admin') {
    const btn = document.getElementById('create-course-btn');
    if (btn) btn.style.display = 'inline-flex';
  }

  // Show enrolled filter only for students
  if (ME.role === 'student') {
    const ef = document.getElementById('enrolled-filter');
    if (ef) ef.style.display = 'inline-block';
  }

  await loadCourses();
})();

// ─── Load & Render ────────────────────────────────────────────────────────────
async function loadCourses() {
  const data = await apiFetch('GET', '/courses/');
  if (!data) return;
  allCourses = data;
  renderCourses();
}

function renderCourses() {
  const grid = document.getElementById('course-grid');
  if (!grid) return;

  let list = [...allCourses];

  if (courseFilter === 'enrolled') list = list.filter(c => c.is_enrolled);
  if (courseSearch) {
    const q = courseSearch.toLowerCase();
    list = list.filter(c =>
      c.title.toLowerCase().includes(q) ||
      (c.description||'').toLowerCase().includes(q)
    );
  }

  if (!list.length) {
    grid.innerHTML = `<div class="empty" style="grid-column:1/-1">
      <span class="e-icon">🔍</span><p>No courses found</p>
    </div>`;
    return;
  }

  grid.innerHTML = list.map((c, i) => {
    const ban   = BANNERS[i % BANNERS.length];
    const emoji = EMOJIS[i % EMOJIS.length];
    const isOwner = (ME.role === 'instructor' && c.instructor === ME.id) || ME.role === 'admin';

    return `<div class="course-card">
      <div class="course-banner ${ban}">${emoji}</div>
      <div class="course-body">
        <div class="course-name">${sanitize(c.title)}</div>
        <div class="course-desc">${sanitize(c.description || 'No description provided.')}</div>
        <div class="course-meta">
          <span>👤 ${sanitize(c.instructor_name)}</span>
          <span>🎒 ${c.enrollment_count}</span>
          <span>📖 ${c.lesson_count} lessons</span>
        </div>
        <div class="course-acts">
          ${ME.role === 'student'
            ? c.is_enrolled
              ? `<span class="chip chip-green">✓ Enrolled</span>
                 <button class="btn btn-ghost btn-sm" onclick="unenroll(${c.id})">Leave</button>`
              : `<button class="btn btn-primary btn-sm" onclick="enroll(${c.id})">Enroll</button>`
            : ''}
          <button class="btn btn-ghost btn-sm" onclick="viewLessons(${c.id},'${sanitize(c.title).replace(/'/g,'\\&#39;')}')">
            📖 Lessons
          </button>
          ${isOwner
            ? `<button class="btn btn-danger btn-xs" onclick="deleteCourse(${c.id})">🗑</button>`
            : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

// ─── Filter & Search ──────────────────────────────────────────────────────────
function cfilt(f, btn) {
  courseFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  renderCourses();
}

function csearch(val) {
  courseSearch = val;
  renderCourses();
}

// ─── Enrollment ───────────────────────────────────────────────────────────────
async function enroll(courseId) {
  const data = await apiFetch('POST', `/courses/${courseId}/enroll/`);
  if (data?.error) { toast(data.error, 'err'); return; }
  toast('Enrolled successfully! 🎉', 'ok');
  await loadCourses();
}

async function unenroll(courseId) {
  const data = await apiFetch('DELETE', `/courses/${courseId}/unenroll/`);
  if (data?.error) { toast(data.error, 'err'); return; }
  toast('Left course', 'info');
  await loadCourses();
}

// ─── Delete Course ────────────────────────────────────────────────────────────
async function deleteCourse(courseId) {
  if (!confirm('Delete this course? This cannot be undone.')) return;
  const data = await apiFetch('DELETE', `/courses/${courseId}/`);
  if (data?.error) { toast(data.error, 'err'); return; }
  toast('Course deleted', 'ok');
  await loadCourses();
}

// ─── Create Course Modal ──────────────────────────────────────────────────────
function openCreateCourseModal() {
  document.getElementById('cc-title').value = '';
  document.getElementById('cc-desc').value  = '';
  openModal('modal-create-course');
}

async function createCourse() {
  const title       = document.getElementById('cc-title').value.trim();
  const description = document.getElementById('cc-desc').value.trim();
  if (!title) { toast('Course title is required', 'err'); return; }

  const data = await apiFetch('POST', '/courses/', { title, description });
  if (data?.error || data?.title) {
    toast(data?.title?.[0] || data?.error || 'Failed to create course', 'err');
    return;
  }
  toast('Course created! 🎉', 'ok');
  closeModal('modal-create-course');
  await loadCourses();
}

// ─── Lessons ──────────────────────────────────────────────────────────────────
let currentCourseId = null;

async function viewLessons(courseId, courseTitle) {
  currentCourseId = courseId;

  const titleEl = document.getElementById('lessons-title');
  if (titleEl) titleEl.textContent = `📖 ${courseTitle}`;

  const body = document.getElementById('lessons-body');
  if (body) body.innerHTML = '<div class="loading">Loading lessons...</div>';

  openModal('modal-lessons');

  const lessons = await apiFetch('GET', `/courses/${courseId}/lessons/`);
  if (!lessons) return;

  if (body) {
    body.innerHTML = lessons.length
      ? lessons.map(l => `
          <div class="lesson-item" onclick="toggleLesson(this)">
            <div class="lesson-num">${l.order_num}</div>
            <div style="flex:1">
              <div class="lesson-title">${sanitize(l.title)}</div>
              <div class="lesson-content">${sanitize(l.content || 'No content yet.')}</div>
            </div>
            <span style="color:var(--text3); font-size:11px; flex-shrink:0;">▼</span>
          </div>`).join('')
      : '<div class="empty"><span class="e-icon">📄</span><p>No lessons yet</p></div>';
  }

  // Add lesson form for instructors/admins
  const formEl = document.getElementById('add-lesson-form');
  if (formEl) {
    const canAdd = ME.role === 'instructor' || ME.role === 'admin';
    formEl.innerHTML = canAdd ? `
      <div class="divider"></div>
      <div style="font-size:13px; font-weight:700; margin-bottom:12px;">➕ Add Lesson</div>
      <div class="field"><label>Title</label><input id="nl-title" placeholder="Lesson title"></div>
      <div class="field"><label>Content</label>
        <textarea class="tinput" id="nl-content" placeholder="Lesson content..."></textarea>
      </div>
      <button class="btn btn-primary btn-sm" onclick="addLesson()">Add Lesson</button>
    ` : '';
  }
}

function toggleLesson(el) {
  const content = el.querySelector('.lesson-content');
  const arrow   = el.querySelector('span:last-child');
  content.style.display = content.style.display === 'block' ? 'none' : 'block';
  arrow.textContent = content.style.display === 'block' ? '▲' : '▼';
}

async function addLesson() {
  const title   = document.getElementById('nl-title')?.value.trim();
  const content = document.getElementById('nl-content')?.value.trim();
  if (!title) { toast('Lesson title is required', 'err'); return; }

  const data = await apiFetch('POST', `/courses/${currentCourseId}/lessons/`, { title, content });
  if (data?.error) { toast(data.error, 'err'); return; }

  toast('Lesson added! 📖', 'ok');
  const course = allCourses.find(c => c.id === currentCourseId);
  await viewLessons(currentCourseId, course?.title || '');
}
