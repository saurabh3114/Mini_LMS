"""
frontend/views.py
Serves the HTML pages for the Mini LMS frontend.
"""
from django.shortcuts import render


def index(request):
    """Login page — entry point of the app."""
    return render(request, 'index.html')


def courses_page(request):
    """Courses listing page."""
    return render(request, 'courses.html')


def assignments_page(request):
    """Assignments & submission page."""
    return render(request, 'assignments.html')
