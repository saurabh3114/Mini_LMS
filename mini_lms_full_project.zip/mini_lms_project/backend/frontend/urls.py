"""
frontend/urls.py
URL routing for the HTML frontend pages.
"""
from django.urls import path
from . import views

urlpatterns = [
    path('',             views.index,            name='index'),
    path('courses/',     views.courses_page,     name='courses-page'),
    path('assignments/', views.assignments_page, name='assignments-page'),
]
