"""
courses/serializers.py
Serializers for courses, lessons, assignments, and submissions.
"""
from rest_framework import serializers
from .models import Course, Lesson, Enrollment, Assignment, Submission
from accounts.serializers import UserSerializer


# ─── Lesson ───────────────────────────────────────────────────────────────────
class LessonSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Lesson
        fields = ['id', 'title', 'content', 'order_num', 'course']
        read_only_fields = ['id']

    def validate_order_num(self, value):
        if value < 1:
            raise serializers.ValidationError('Order number must be 1 or greater.')
        return value


# ─── Course ───────────────────────────────────────────────────────────────────
class CourseSerializer(serializers.ModelSerializer):
    instructor_name  = serializers.CharField(source='instructor.username', read_only=True)
    enrollment_count = serializers.IntegerField(read_only=True)
    lesson_count     = serializers.IntegerField(read_only=True)
    is_enrolled      = serializers.SerializerMethodField()

    class Meta:
        model  = Course
        fields = [
            'id', 'title', 'description',
            'instructor', 'instructor_name',
            'enrollment_count', 'lesson_count',
            'is_enrolled', 'created_at',
        ]
        read_only_fields = ['id', 'instructor', 'created_at']

    def get_is_enrolled(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated and request.user.is_student:
            return obj.enrollments.filter(student=request.user).exists()
        return False


class CourseCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Course
        fields = ['id', 'title', 'description']
        read_only_fields = ['id']

    def create(self, validated_data):
        validated_data['instructor'] = self.context['request'].user
        return super().create(validated_data)


# ─── Enrollment ───────────────────────────────────────────────────────────────
class EnrollmentSerializer(serializers.ModelSerializer):
    course_title = serializers.CharField(source='course.title', read_only=True)
    student_name = serializers.CharField(source='student.username', read_only=True)

    class Meta:
        model  = Enrollment
        fields = ['id', 'student', 'student_name', 'course', 'course_title', 'enrolled_at']
        read_only_fields = ['id', 'student', 'enrolled_at']


# ─── Assignment ───────────────────────────────────────────────────────────────
class AssignmentSerializer(serializers.ModelSerializer):
    course_title     = serializers.CharField(source='course.title', read_only=True)
    submission_count = serializers.IntegerField(read_only=True)
    my_submission    = serializers.SerializerMethodField()
    my_grade         = serializers.SerializerMethodField()
    my_feedback      = serializers.SerializerMethodField()

    class Meta:
        model  = Assignment
        fields = [
            'id', 'title', 'description', 'course', 'course_title',
            'due_date', 'max_marks', 'submission_count',
            'my_submission', 'my_grade', 'my_feedback', 'created_at',
        ]
        read_only_fields = ['id', 'created_at']

    def _get_my_sub(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated and request.user.is_student:
            return obj.submissions.filter(student=request.user).first()
        return None

    def get_my_submission(self, obj):
        sub = self._get_my_sub(obj)
        return sub.content if sub else None

    def get_my_grade(self, obj):
        sub = self._get_my_sub(obj)
        return sub.grade if sub else None

    def get_my_feedback(self, obj):
        sub = self._get_my_sub(obj)
        return sub.feedback if sub else None


# ─── Submission ───────────────────────────────────────────────────────────────
class SubmissionSerializer(serializers.ModelSerializer):
    student_name      = serializers.CharField(source='student.username', read_only=True)
    student_email     = serializers.CharField(source='student.email', read_only=True)
    assignment_title  = serializers.CharField(source='assignment.title', read_only=True)

    class Meta:
        model  = Submission
        fields = [
            'id', 'assignment', 'assignment_title',
            'student', 'student_name', 'student_email',
            'content', 'grade', 'feedback',
            'submitted_at', 'updated_at',
        ]
        read_only_fields = ['id', 'student', 'submitted_at', 'updated_at']


class SubmitSerializer(serializers.ModelSerializer):
    """Used by students to create/update their submission."""

    class Meta:
        model  = Submission
        fields = ['assignment', 'content']

    def validate_content(self, value):
        if not value.strip():
            raise serializers.ValidationError('Submission content cannot be empty.')
        return value


class GradeSerializer(serializers.ModelSerializer):
    """Used by instructors to grade a submission."""

    class Meta:
        model  = Submission
        fields = ['grade', 'feedback']

    def validate_grade(self, value):
        submission = self.instance
        if submission and value > submission.assignment.max_marks:
            raise serializers.ValidationError(
                f'Grade cannot exceed max marks ({submission.assignment.max_marks}).'
            )
        return value


# ─── Stats ────────────────────────────────────────────────────────────────────
class StatsSerializer(serializers.Serializer):
    """Dashboard statistics — shape varies by role."""
    pass  # Dynamically built in views
