"""
courses/permissions.py
Custom DRF permissions for role-based access control.
"""
from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsInstructor(BasePermission):
    """Allow access only to instructors and admins."""
    message = 'Only instructors or admins can perform this action.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role in ('instructor', 'admin')
        )


class IsStudent(BasePermission):
    """Allow access only to students."""
    message = 'Only students can perform this action.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role == 'student'
        )


class IsAdminUser(BasePermission):
    """Allow access only to admins."""
    message = 'Only admins can perform this action.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role == 'admin'
        )


class IsOwnerOrAdmin(BasePermission):
    """Allow object-level access to the owner or admin."""
    message = 'You do not have permission to modify this object.'

    def has_object_permission(self, request, view, obj):
        if request.user.role == 'admin':
            return True
        # Check instructor ownership on Course objects
        if hasattr(obj, 'instructor'):
            return obj.instructor == request.user
        # Check student ownership on Submission objects
        if hasattr(obj, 'student'):
            return obj.student == request.user
        return False


class ReadOnly(BasePermission):
    """Allow GET/HEAD/OPTIONS to any authenticated user."""
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.method in SAFE_METHODS
