"""
courses/admin.py
Django admin for all course-related models.
"""
from django.contrib import admin
from .models import Course, Lesson, Enrollment, Assignment, Submission


class LessonInline(admin.TabularInline):
    model  = Lesson
    extra  = 1
    fields = ('order_num', 'title', 'content')


class AssignmentInline(admin.TabularInline):
    model  = Assignment
    extra  = 0
    fields = ('title', 'due_date', 'max_marks')


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display  = ('title', 'instructor', 'enrollment_count', 'lesson_count', 'created_at')
    list_filter   = ('instructor',)
    search_fields = ('title', 'description')
    inlines       = [LessonInline, AssignmentInline]


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display  = ('title', 'course', 'order_num')
    list_filter   = ('course',)
    search_fields = ('title',)
    ordering      = ('course', 'order_num')


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display  = ('student', 'course', 'enrolled_at')
    list_filter   = ('course',)
    search_fields = ('student__username', 'course__title')


@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display  = ('title', 'course', 'due_date', 'max_marks', 'submission_count')
    list_filter   = ('course',)
    search_fields = ('title',)


@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display  = ('student', 'assignment', 'grade', 'submitted_at')
    list_filter   = ('assignment__course',)
    search_fields = ('student__username', 'assignment__title')
    readonly_fields = ('submitted_at', 'updated_at')
