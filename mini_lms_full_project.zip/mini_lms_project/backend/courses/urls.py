"""
courses/urls.py
URL routing for courses, lessons, assignments, and submissions.
"""
from django.urls import path
from . import views

urlpatterns = [
    # Courses
    path('',                                    views.course_list_create,    name='course-list'),
    path('<int:course_id>/',                    views.course_detail,         name='course-detail'),
    path('<int:course_id>/enroll/',             views.enroll,                name='enroll'),
    path('<int:course_id>/unenroll/',           views.unenroll,              name='unenroll'),

    # Lessons
    path('<int:course_id>/lessons/',            views.lesson_list_create,    name='lesson-list'),
    path('<int:course_id>/lessons/<int:lesson_id>/', views.lesson_delete,   name='lesson-delete'),

    # Assignments
    path('assignments/',                        views.assignment_list_create, name='assignment-list'),
    path('assignments/<int:assignment_id>/submissions/', views.assignment_submissions, name='assignment-submissions'),
    path('assignments/<int:assignment_id>/grade/<int:student_id>/', views.grade_submission, name='grade-submission'),

    # Submissions
    path('submit/',                             views.submit_assignment,     name='submit'),

    # Stats
    path('stats/',                              views.stats_view,            name='stats'),
]
