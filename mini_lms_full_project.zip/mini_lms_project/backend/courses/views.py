"""
courses/views.py
API views for courses, lessons, assignments, submissions, and stats.
"""
from django.db.models import Avg, Count
from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Course, Lesson, Enrollment, Assignment, Submission
from .serializers import (
    CourseSerializer, CourseCreateSerializer,
    LessonSerializer,
    AssignmentSerializer,
    SubmissionSerializer, SubmitSerializer, GradeSerializer,
)
from .permissions import IsInstructor, IsStudent, IsOwnerOrAdmin


# ════════════════════════════════════════════════════════════
#  COURSES
# ════════════════════════════════════════════════════════════

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def course_list_create(request):
    """
    GET  /api/courses/         — List courses (filtered by role)
    POST /api/courses/         — Create a new course (instructor/admin)
    """
    if request.method == 'GET':
        user = request.user
        if user.role == 'student':
            # All courses (student sees all to allow browsing + enrolling)
            qs = Course.objects.all()
        elif user.role == 'instructor':
            qs = Course.objects.filter(instructor=user)
        else:
            qs = Course.objects.all()

        qs = qs.annotate(
            enrollment_count=Count('enrollments', distinct=True),
            lesson_count=Count('lessons', distinct=True),
        )
        return Response(CourseSerializer(qs, many=True, context={'request': request}).data)

    # POST — create course
    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Only instructors can create courses.'}, status=403)

    serializer = CourseCreateSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        course = serializer.save()
        return Response(
            CourseSerializer(course, context={'request': request}).data,
            status=status.HTTP_201_CREATED,
        )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def course_detail(request, course_id):
    """
    GET    /api/courses/<id>/  — Course detail
    PUT    /api/courses/<id>/  — Update course (instructor/admin)
    DELETE /api/courses/<id>/  — Delete course (instructor/admin)
    """
    course = get_object_or_404(Course, pk=course_id)

    if request.method == 'GET':
        return Response(CourseSerializer(course, context={'request': request}).data)

    # Modification requires ownership or admin
    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Permission denied.'}, status=403)
    if request.user.role == 'instructor' and course.instructor != request.user:
        return Response({'error': 'You can only modify your own courses.'}, status=403)

    if request.method == 'DELETE':
        course.delete()
        return Response({'success': True}, status=status.HTTP_204_NO_CONTENT)

    if request.method == 'PUT':
        serializer = CourseCreateSerializer(course, data=request.data, partial=True, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(CourseSerializer(course, context={'request': request}).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ════════════════════════════════════════════════════════════
#  ENROLLMENT
# ════════════════════════════════════════════════════════════

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def enroll(request, course_id):
    """POST /api/courses/<id>/enroll/ — Student enrolls in a course."""
    if not request.user.is_student:
        return Response({'error': 'Only students can enroll.'}, status=403)

    course = get_object_or_404(Course, pk=course_id)
    enrollment, created = Enrollment.objects.get_or_create(
        student=request.user,
        course=course,
    )
    if not created:
        return Response({'error': 'Already enrolled in this course.'}, status=400)

    return Response({'success': True, 'message': f'Enrolled in {course.title}!'}, status=201)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def unenroll(request, course_id):
    """DELETE /api/courses/<id>/unenroll/ — Student unenrolls from a course."""
    if not request.user.is_student:
        return Response({'error': 'Only students can unenroll.'}, status=403)

    course = get_object_or_404(Course, pk=course_id)
    deleted, _ = Enrollment.objects.filter(student=request.user, course=course).delete()
    if not deleted:
        return Response({'error': 'You are not enrolled in this course.'}, status=400)

    return Response({'success': True})


# ════════════════════════════════════════════════════════════
#  LESSONS
# ════════════════════════════════════════════════════════════

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def lesson_list_create(request, course_id):
    """
    GET  /api/courses/<id>/lessons/  — List lessons for a course
    POST /api/courses/<id>/lessons/  — Add a lesson (instructor/admin)
    """
    course = get_object_or_404(Course, pk=course_id)

    if request.method == 'GET':
        lessons = course.lessons.all()
        return Response(LessonSerializer(lessons, many=True).data)

    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Only instructors can add lessons.'}, status=403)
    if request.user.role == 'instructor' and course.instructor != request.user:
        return Response({'error': 'You can only add lessons to your own courses.'}, status=403)

    # Auto-assign next order number
    data = request.data.copy()
    last_order = course.lessons.aggregate(max_order=Count('id'))['max_order'] or 0
    data['order_num'] = last_order + 1
    data['course'] = course_id

    serializer = LessonSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def lesson_delete(request, course_id, lesson_id):
    """DELETE /api/courses/<course_id>/lessons/<lesson_id>/ — Delete a lesson."""
    course = get_object_or_404(Course, pk=course_id)
    lesson = get_object_or_404(Lesson, pk=lesson_id, course=course)

    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Permission denied.'}, status=403)
    if request.user.role == 'instructor' and course.instructor != request.user:
        return Response({'error': 'Permission denied.'}, status=403)

    lesson.delete()
    return Response({'success': True}, status=204)


# ════════════════════════════════════════════════════════════
#  ASSIGNMENTS
# ════════════════════════════════════════════════════════════

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def assignment_list_create(request):
    """
    GET  /api/courses/assignments/  — List assignments (role-filtered)
    POST /api/courses/assignments/  — Create assignment (instructor/admin)
    """
    user = request.user

    if request.method == 'GET':
        if user.role == 'student':
            enrolled_courses = Enrollment.objects.filter(student=user).values_list('course_id', flat=True)
            qs = Assignment.objects.filter(course_id__in=enrolled_courses)
        elif user.role == 'instructor':
            qs = Assignment.objects.filter(course__instructor=user)
        else:
            qs = Assignment.objects.all()

        qs = qs.annotate(submission_count=Count('submissions', distinct=True))
        return Response(AssignmentSerializer(qs, many=True, context={'request': request}).data)

    # POST
    if user.role not in ('instructor', 'admin'):
        return Response({'error': 'Only instructors can create assignments.'}, status=403)

    serializer = AssignmentSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ════════════════════════════════════════════════════════════
#  SUBMISSIONS
# ════════════════════════════════════════════════════════════

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def submit_assignment(request):
    """
    POST /api/courses/submit/
    Student submits (or re-submits) an assignment.
    """
    if not request.user.is_student:
        return Response({'error': 'Only students can submit assignments.'}, status=403)

    serializer = SubmitSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    assignment = serializer.validated_data['assignment']

    # Verify student is enrolled in the course
    enrolled = Enrollment.objects.filter(
        student=request.user,
        course=assignment.course,
    ).exists()
    if not enrolled:
        return Response({'error': 'You must be enrolled in the course to submit.'}, status=403)

    submission, created = Submission.objects.update_or_create(
        assignment=assignment,
        student=request.user,
        defaults={'content': serializer.validated_data['content']},
    )
    return Response(
        SubmissionSerializer(submission).data,
        status=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
    )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def assignment_submissions(request, assignment_id):
    """
    GET /api/courses/assignments/<id>/submissions/
    Instructor/admin views all submissions for an assignment.
    """
    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Permission denied.'}, status=403)

    assignment = get_object_or_404(Assignment, pk=assignment_id)

    # Instructors can only see submissions for their own courses
    if request.user.role == 'instructor' and assignment.course.instructor != request.user:
        return Response({'error': 'Permission denied.'}, status=403)

    submissions = assignment.submissions.select_related('student')
    return Response(SubmissionSerializer(submissions, many=True).data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def grade_submission(request, assignment_id, student_id):
    """
    POST /api/courses/assignments/<id>/grade/<student_id>/
    Instructor grades a student's submission.
    """
    if request.user.role not in ('instructor', 'admin'):
        return Response({'error': 'Only instructors can grade submissions.'}, status=403)

    assignment = get_object_or_404(Assignment, pk=assignment_id)
    if request.user.role == 'instructor' and assignment.course.instructor != request.user:
        return Response({'error': 'Permission denied.'}, status=403)

    submission = get_object_or_404(Submission, assignment=assignment, student_id=student_id)

    serializer = GradeSerializer(submission, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(SubmissionSerializer(submission).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ════════════════════════════════════════════════════════════
#  DASHBOARD STATS
# ════════════════════════════════════════════════════════════

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def stats_view(request):
    """GET /api/courses/stats/ — Dashboard statistics (role-aware)."""
    user = request.user

    if user.role == 'student':
        enrollments = Enrollment.objects.filter(student=user)
        submissions = Submission.objects.filter(student=user)
        graded      = submissions.filter(grade__isnull=False)
        avg_grade   = graded.aggregate(avg=Avg('grade'))['avg']

        return Response({
            'enrolled':  enrollments.count(),
            'submitted': submissions.count(),
            'graded':    graded.count(),
            'avg_grade': round(avg_grade, 1) if avg_grade else None,
        })

    if user.role == 'instructor':
        my_courses  = Course.objects.filter(instructor=user)
        my_ids      = my_courses.values_list('id', flat=True)
        enrolled    = Enrollment.objects.filter(course_id__in=my_ids)
        assignments = Assignment.objects.filter(course_id__in=my_ids)
        pending     = Submission.objects.filter(
            assignment__course_id__in=my_ids,
            grade__isnull=True,
        )
        return Response({
            'courses':       my_courses.count(),
            'students':      enrolled.values('student').distinct().count(),
            'assignments':   assignments.count(),
            'pending_grade': pending.count(),
        })

    # Admin
    from accounts.models import User as UserModel
    return Response({
        'users':       UserModel.objects.count(),
        'courses':     Course.objects.count(),
        'submissions': Submission.objects.count(),
        'enrollments': Enrollment.objects.count(),
    })
