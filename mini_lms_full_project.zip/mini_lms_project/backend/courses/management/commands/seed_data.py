"""
courses/management/commands/seed_data.py
Seeds the database with demo users, courses, lessons, and assignments.

Usage:
    python manage.py seed_data
    python manage.py seed_data --flush   # clears existing data first
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model

from courses.models import Course, Lesson, Enrollment, Assignment, Submission

User = get_user_model()

USERS = [
    {'username': 'admin',      'password': 'Admin@2025!',      'role': 'admin',      'email': 'admin@lms.com'},
    {'username': 'prof_smith', 'password': 'Teach#Smith99',    'role': 'instructor', 'email': 'smith@lms.com'},
    {'username': 'prof_jones', 'password': 'Jones@Prof2025',   'role': 'instructor', 'email': 'jones@lms.com'},
    {'username': 'alice',      'password': 'Alice#Pass1',      'role': 'student',    'email': 'alice@lms.com'},
    {'username': 'bob',        'password': 'Bob#Pass1',        'role': 'student',    'email': 'bob@lms.com'},
    {'username': 'charlie',    'password': 'Charlie#Pass1',    'role': 'student',    'email': 'charlie@lms.com'},
    {'username': 'diana',      'password': 'Diana#Pass1',      'role': 'student',    'email': 'diana@lms.com'},
    {'username': 'eve',        'password': 'Eve#Pass1',        'role': 'student',    'email': 'eve@lms.com'},
    {'username': 'frank',      'password': 'Frank#Pass1',      'role': 'student',    'email': 'frank@lms.com'},
    {'username': 'grace',      'password': 'Grace#Pass1',      'role': 'student',    'email': 'grace@lms.com'},
    {'username': 'henry',      'password': 'Henry#Pass1',      'role': 'student',    'email': 'henry@lms.com'},
]


class Command(BaseCommand):
    help = 'Seeds the database with demo users, courses, and assignments.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--flush',
            action='store_true',
            help='Delete all existing LMS data before seeding.',
        )

    def handle(self, *args, **options):
        if options['flush']:
            self.stdout.write('🗑  Flushing existing data...')
            Submission.objects.all().delete()
            Enrollment.objects.all().delete()
            Assignment.objects.all().delete()
            Lesson.objects.all().delete()
            Course.objects.all().delete()
            User.objects.all().delete()

        self.stdout.write('👤 Creating users...')
        user_map = {}
        for u in USERS:
            obj, created = User.objects.get_or_create(username=u['username'])
            if created or options['flush']:
                obj.set_password(u['password'])
                obj.role  = u['role']
                obj.email = u['email']
                obj.is_superuser = (u['role'] == 'admin')
                obj.is_staff     = (u['role'] == 'admin')
                obj.save()
            user_map[u['username']] = obj
            status = '✅ created' if created else '⏭  exists'
            self.stdout.write(f'   {status}: {u["username"]} ({u["role"]})')

        self.stdout.write('📚 Creating courses...')
        smith = user_map['prof_smith']
        jones = user_map['prof_jones']

        c1, _ = Course.objects.get_or_create(
            title='Python Fundamentals',
            defaults={'description': 'Master Python from scratch with hands-on projects.', 'instructor': smith},
        )
        c2, _ = Course.objects.get_or_create(
            title='Web Development Bootcamp',
            defaults={'description': 'HTML, CSS, JavaScript & Django full-stack course.', 'instructor': smith},
        )
        c3, _ = Course.objects.get_or_create(
            title='Data Science 101',
            defaults={'description': 'Introduction to data analysis, pandas & matplotlib.', 'instructor': jones},
        )
        c4, _ = Course.objects.get_or_create(
            title='Machine Learning Basics',
            defaults={'description': 'Supervised learning, regression, classification with scikit-learn.', 'instructor': jones},
        )

        self.stdout.write('📖 Creating lessons...')
        lessons_data = [
            (c1, 1, 'Variables & Data Types',      'Learn Python variables: int, str, float, bool, type conversion.'),
            (c1, 2, 'Control Flow',                 'if/elif/else, for loops, while loops, break, continue.'),
            (c1, 3, 'Functions & Scope',            'Defining functions, parameters, return values, scope, lambda.'),
            (c1, 4, 'Lists, Tuples & Dicts',        'Python collections: indexing, slicing, dict methods.'),
            (c2, 1, 'HTML Basics',                  'Document structure, semantic tags, forms, tables.'),
            (c2, 2, 'CSS & Flexbox',                'Selectors, box model, flexbox, grid, responsive design.'),
            (c2, 3, 'JavaScript Fundamentals',      'Variables, DOM manipulation, events, fetch API.'),
            (c3, 1, 'Introduction to Pandas',       'DataFrames, Series, read_csv, filtering, groupby.'),
            (c3, 2, 'Data Visualization',           'matplotlib & seaborn: line charts, bar charts, heatmaps.'),
            (c4, 1, 'What is Machine Learning?',    'Types of ML, the ML pipeline, train/test split.'),
            (c4, 2, 'Linear Regression',            'Regression theory, scikit-learn, evaluation metrics.'),
        ]
        for (course, order, title, content) in lessons_data:
            Lesson.objects.get_or_create(course=course, order_num=order,
                                         defaults={'title': title, 'content': content})

        self.stdout.write('📝 Creating assignments...')
        assignments_data = [
            (c1, 'Hello World Project',   'Write a Python program that prints your name and a greeting.', '2025-03-01', 50),
            (c1, 'Calculator App',        'Build a calculator using Python functions.', '2025-03-15', 100),
            (c2, 'Personal Webpage',      'Create a personal HTML + CSS page with your bio.', '2025-03-20', 100),
            (c2, 'Todo App (JS)',         'Build a todo list app using vanilla JavaScript.', '2025-04-05', 100),
            (c3, 'Data Analysis Report',  'Load a CSV dataset with pandas and generate 3 insights.', '2025-04-01', 100),
            (c4, 'Regression Model',      'Train a linear regression model on the provided dataset.', '2025-04-15', 100),
        ]
        assign_map = {}
        for (course, title, desc, due, marks) in assignments_data:
            a, _ = Assignment.objects.get_or_create(
                course=course, title=title,
                defaults={'description': desc, 'due_date': due, 'max_marks': marks},
            )
            assign_map[title] = a

        self.stdout.write('🔗 Creating enrollments...')
        enrollments = [
            ('alice',   c1), ('alice',   c2),
            ('bob',     c1), ('bob',     c3),
            ('charlie', c1), ('charlie', c2), ('charlie', c3),
            ('diana',   c2), ('diana',   c3),
            ('eve',     c1),
            ('frank',   c1), ('frank',   c4),
            ('grace',   c3), ('grace',   c4),
            ('henry',   c1), ('henry',   c3),
        ]
        for (username, course) in enrollments:
            Enrollment.objects.get_or_create(student=user_map[username], course=course)

        self.stdout.write('✅ Creating sample submissions...')
        subs = [
            ('alice',   'Hello World Project', 'print("Hello World! My name is Alice")', 45, 'Excellent! Clean solution.'),
            ('alice',   'Calculator App',      'def add(a,b): return a+b\ndef sub(a,b): return a-b', None, None),
            ('bob',     'Hello World Project', 'print("Hello! I am Bob")', 40, 'Good job!'),
            ('charlie', 'Hello World Project', 'print("Hi! Charlie here")', 48, 'Near perfect!'),
            ('charlie', 'Personal Webpage',    '<html><body><h1>Charlie</h1></body></html>', None, None),
            ('diana',   'Personal Webpage',    '<html><body><h1>Diana Portfolio</h1></body></html>', 88, 'Great styling!'),
            ('eve',     'Hello World Project', 'print("Eve says Hello!")', None, None),
        ]
        for (username, assign_title, content, grade, feedback) in subs:
            a = assign_map.get(assign_title)
            if a:
                Submission.objects.get_or_create(
                    assignment=a,
                    student=user_map[username],
                    defaults={'content': content, 'grade': grade, 'feedback': feedback},
                )

        self.stdout.write(self.style.SUCCESS('\n🎉 Database seeded successfully!\n'))
        self.stdout.write('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        self.stdout.write('Demo accounts:')
        for u in USERS:
            self.stdout.write(f'  {u["role"]:12} | {u["username"]:12} | {u["password"]}')
        self.stdout.write('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
