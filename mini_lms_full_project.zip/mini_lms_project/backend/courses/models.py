"""
courses/models.py
Models: Course, Lesson, Enrollment, Assignment, Submission.
"""
from django.db import models
from django.conf import settings


class Course(models.Model):
    title       = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    instructor  = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='courses_taught',
        limit_choices_to={'role__in': ['instructor', 'admin']},
    )
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

    @property
    def enrollment_count(self):
        return self.enrollments.count()

    @property
    def lesson_count(self):
        return self.lessons.count()

    class Meta:
        ordering = ['-created_at']


class Lesson(models.Model):
    course    = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons')
    title     = models.CharField(max_length=200)
    content   = models.TextField(blank=True)
    order_num = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f'[{self.course.title}] Lesson {self.order_num}: {self.title}'

    class Meta:
        ordering = ['order_num']
        unique_together = ['course', 'order_num']


class Enrollment(models.Model):
    student     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='enrollments',
        limit_choices_to={'role': 'student'},
    )
    course      = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    enrolled_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['student', 'course']
        ordering = ['-enrolled_at']

    def __str__(self):
        return f'{self.student.username} → {self.course.title}'


class Assignment(models.Model):
    course      = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='assignments')
    title       = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date    = models.DateField(null=True, blank=True)
    max_marks   = models.PositiveIntegerField(default=100)
    created_at  = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'[{self.course.title}] {self.title}'

    class Meta:
        ordering = ['due_date', 'created_at']

    @property
    def submission_count(self):
        return self.submissions.count()


class Submission(models.Model):
    assignment   = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name='submissions')
    student      = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='submissions',
        limit_choices_to={'role': 'student'},
    )
    content      = models.TextField()
    grade        = models.PositiveIntegerField(null=True, blank=True)
    feedback     = models.TextField(blank=True, null=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['assignment', 'student']
        ordering = ['-submitted_at']

    def __str__(self):
        grade_str = f' — Grade: {self.grade}' if self.grade is not None else ' (ungraded)'
        return f'{self.student.username} → {self.assignment.title}{grade_str}'
